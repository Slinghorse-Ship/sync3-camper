import QtQuick 2.6

Item {
    id: panels
    objectName: "v2EdgePanelsHost"

    property var api
    property var host
    property var favorites: []
    property var favoriteIds: []
    property var favoriteOptions: []
    property var weather: ({})
    property bool dayMode: false
    property int activePanel: 0 // -1 = Favoriten, 0 = geschlossen, 1 = Wetter
    readonly property color tideColor: dayMode ? "#008da3" : "#63e6f2"

    readonly property var hourlyForecast: weather && weather.hourly && weather.hourly.length
        ? weather.hourly : (weather && weather.forecast && weather.forecast.length ? weather.forecast : [])
    readonly property var dailyForecast: weather && weather.daily && weather.daily.length
        ? weather.daily : (weather && weather.dailyForecast && weather.dailyForecast.length ? weather.dailyForecast : [])
    readonly property var currentWeather: currentHourly()
    readonly property bool weatherAvailable: hourlyForecast.length > 0 || dailyForecast.length > 0
    readonly property var tides: weather && weather.tides && typeof weather.tides === "object" ? weather.tides : null
    readonly property bool tidesAvailable: validTides(tides)
    readonly property bool tideCurveAvailable: validTideCurve(tides)
    readonly property var tideCurve: tideCurveAvailable ? tides.curve : []

    CamperStyle { id: visual; dayMode: panels.dayMode }

    function close() { activePanel = 0 }
    function openFavorites() { activePanel = -1 }
    function openWeather() { activePanel = 1 }

    function validNumber(value) {
        return value !== null && value !== undefined && value !== "" && isFinite(Number(value))
    }

    function numberFrom(object, primary, secondary) {
        if (object && validNumber(object[primary])) return Number(object[primary])
        if (object && secondary && validNumber(object[secondary])) return Number(object[secondary])
        return null
    }

    function textFrom(object, primary, secondary) {
        if (object && object[primary] !== null && object[primary] !== undefined && String(object[primary]).length)
            return String(object[primary])
        if (object && secondary && object[secondary] !== null && object[secondary] !== undefined && String(object[secondary]).length)
            return String(object[secondary])
        return ""
    }

    function temperatureText(object) {
        var value = numberFrom(object, "temperature", "temperatureC")
        if (value === null) value = numberFrom(object, "tempC", "temp")
        return value === null ? "–°" : value.toFixed(1) + "°"
    }

    function detailText(label, value, suffix) {
        return validNumber(value) ? label + " " + Number(value).toFixed(0) + suffix : ""
    }

    function weatherLocation() {
        if (!weather) return "Wetter"
        if (weather.station && weather.station.name) return String(weather.station.name)
        if (typeof weather.location === "string" && weather.location.length) return weather.location
        if (weather.location && weather.location.name) return String(weather.location.name)
        return textFrom(weather, "stationName", "locationName") || "Wetter"
    }

    function weatherUpdatedText() {
        var value = weather && (weather.fetchedAtUtc || weather.updatedAt || weather.observedAt)
        if (!value) return ""
        var date = new Date(value)
        if (isNaN(date.getTime())) return ""
        return "Stand " + Qt.formatDateTime(date, "dd.MM. hh:mm")
    }

    function sunTime(key) {
        var value = weather && weather.sun ? weather.sun[key] : null
        if (!value) return "–"
        var date = new Date(value)
        return isNaN(date.getTime()) ? "–" : Qt.formatTime(date, "hh:mm")
    }

    function validIsoTimestamp(value) {
        if (typeof value !== "string" || !/(Z|[+-]\d\d:\d\d)$/.test(value)) return false
        var date = new Date(value)
        return !isNaN(date.getTime())
    }

    function validTideEvent(event) {
        return event && typeof event === "object" && validIsoTimestamp(event.t)
                && (event.heightM === null || validNumber(event.heightM))
    }

    function validTides(data) {
        if (!data || typeof data !== "object" || data.source !== "BSH" || data.referenceLevel !== "PNP") return false
        if (!data.attribution || data.license !== "CC BY 4.0"
                || data.licenseUrl !== "https://creativecommons.org/licenses/by/4.0/"
                || typeof data.changes !== "string" || !data.changes.length || data.changes.length > 256
                || !validIsoTimestamp(data.updatedUtc)
                || (data.stale !== true && data.stale !== false)) return false
        var station = data.station
        if (!station || typeof station !== "object" || !station.id || !station.name
                || !validNumber(station.distanceKm)) return false
        return validTideEvent(data.nextHigh) && validTideEvent(data.nextLow)
    }

    function validTideCurve(data) {
        if (!validTides(data) || !data.curve || typeof data.curve.length !== "number"
                || data.curve.length < 2 || data.curve.length > 27) return false
        var previousTime = -1
        for (var i = 0; i < data.curve.length; ++i) {
            var point = data.curve[i]
            if (!point || typeof point !== "object" || !validIsoTimestamp(point.t)
                    || typeof point.heightM !== "number" || !isFinite(point.heightM)
                    || point.heightM < -20 || point.heightM > 20) return false
            var pointTime = new Date(point.t).getTime()
            if (pointTime <= previousTime) return false
            previousTime = pointTime
        }
        return true
    }

    function tideEventText(label, event, markStale) {
        if (!validTideEvent(event)) return ""
        var date = new Date(event.t)
        var height = event.heightM === null ? "–" : Number(event.heightM).toFixed(1).replace(".", ",") + " m PNP"
        return label + " " + Qt.formatTime(date, "hh:mm") + " · " + height
                + (markStale && tides.stale === true ? " · veraltet" : "")
    }

    function tideSummary() {
        if (!tidesAvailable) return ""
        return tideEventText("HW", tides.nextHigh, true) + "\n" + tideEventText("NW", tides.nextLow, false)
    }

    function sunLabel() {
        var rise = sunTime("riseUtc")
        var set = sunTime("setUtc")
        return rise === "–" || set === "–" ? "" : "Sonne ↑" + rise + " ↓" + set
    }

    function tideLabel() {
        if (!tidesAvailable) return ""
        function eventText(label, event) {
            var date = new Date(event.t)
            var height = event.heightM === null ? "" : " " + Number(event.heightM).toFixed(2).replace(".", ",") + " m"
            return label + " " + Qt.formatTime(date, "hh:mm") + height
        }
        var station = tides.station && tides.station.name ? " · " + String(tides.station.name) : ""
        return "BSH Tide " + eventText("HW", tides.nextHigh) + " · " + eventText("NW", tides.nextLow)
                + station + (tides.stale === true ? " · veraltet" : "")
    }

    function currentHourly() {
        if (!hourlyForecast || !hourlyForecast.length) return ({})
        var now = new Date().getTime()
        for (var i = 0; i < hourlyForecast.length; ++i) {
            var value = hourlyForecast[i] && (hourlyForecast[i].t || hourlyForecast[i].timestamp || hourlyForecast[i].time || hourlyForecast[i].validAt)
            var time = new Date(value).getTime()
            if (isNaN(time) || time >= now - 3600000) return hourlyForecast[i]
        }
        return hourlyForecast[hourlyForecast.length - 1]
    }

    function forecastTime(item) {
        var value = item && (item.t || item.timestamp || item.time || item.at || item.validAt)
        if (!value) return textFrom(item, "label", "period") || "–"
        var date = new Date(value)
        return isNaN(date.getTime()) ? String(value) : Qt.formatTime(date, "hh:mm")
    }

    function dailyLabel(item) {
        var value = item && (item.date || item.timestamp || item.time || item.validAt)
        if (!value) return textFrom(item, "label", "day") || "–"
        var date = new Date(value)
        return isNaN(date.getTime()) ? String(value) : Qt.formatDate(date, "ddd")
    }

    function minimumTemperature(item) {
        var value = numberFrom(item, "minC", "temperatureMin")
        if (value === null) value = numberFrom(item, "minTemperature", "minTemperatureC")
        if (value === null) value = numberFrom(item, "minTemperatureC", "tempMin")
        return value
    }

    function maximumTemperature(item) {
        var value = numberFrom(item, "maxC", "temperatureMax")
        if (value === null) value = numberFrom(item, "maxTemperature", "maxTemperatureC")
        if (value === null) value = numberFrom(item, "maxTemperatureC", "tempMax")
        return value
    }

    function rainProbability(item) {
        var value = numberFrom(item, "precipProbabilityPct", "maxHourlyPrecipProbabilityPct")
        if (value === null) value = numberFrom(item, "precipitationProbability", "precipitationProbabilityPercent")
        if (value === null) value = numberFrom(item, "rainProbability", "probabilityOfPrecipitation")
        return value
    }

    function rainAmount(item) {
        var value = numberFrom(item, "precipMm", "precipitation")
        if (value === null) value = numberFrom(item, "precipitationMm", "rr1c")
        if (value === null) value = numberFrom(item, "rr1c", "RR1c")
        return value
    }

    function chartUsesProbability() {
        for (var i = 0; i < Math.min(24, hourlyForecast.length); ++i)
            if (rainProbability(hourlyForecast[i]) !== null) return true
        return false
    }

    function chartRainValue(item) {
        return chartUsesProbability() ? rainProbability(item) : rainAmount(item)
    }

    function chartRainLabel() {
        return chartUsesProbability() ? "Regen %" : "RR1c mm"
    }

    function weatherIcon(item) {
        var value = textFrom(item, "icon", "condition")
        var fallback = textFrom(item, "condition", "summary")
        value = (value + " " + fallback).toLowerCase()
        if (value.indexOf("hail") >= 0 || value.indexOf("hagel") >= 0) return "weatherHail"
        if (value.indexOf("storm") >= 0 || value.indexOf("thunder") >= 0 || value.indexOf("gewitter") >= 0) return "weatherStorm"
        if (value.indexOf("freezing") >= 0 || value.indexOf("gefrier") >= 0 || value.indexOf("ice-rain") >= 0) return "weatherFreezingRain"
        if (value.indexOf("sleet") >= 0 || value.indexOf("mixed") >= 0 || value.indexOf("schneeregen") >= 0) return "weatherSleet"
        if (value.indexOf("snow") >= 0 || value.indexOf("schnee") >= 0) return "weatherSnow"
        if (value.indexOf("rain") >= 0 || value.indexOf("regen") >= 0 || value.indexOf("shower") >= 0 || value.indexOf("drizzle") >= 0 || value.indexOf("sprüh") >= 0) return "weatherRain"
        if (value.indexOf("fog") >= 0 || value.indexOf("mist") >= 0 || value.indexOf("nebel") >= 0) return "weatherFog"
        if (value.indexOf("partly-cloudy") >= 0 || value.indexOf("mostly-clear") >= 0 || value.indexOf("aufgelockert") >= 0) return "weatherPartly"
        if (value.indexOf("clear") >= 0 || value.indexOf("sun") >= 0 || value.indexOf("sonn") >= 0) return "weatherClear"
        if (value.indexOf("cloud") >= 0 || value.indexOf("overcast") >= 0 || value.indexOf("bewölk") >= 0 || value.indexOf("bedeckt") >= 0 || value.indexOf("wolk") >= 0) return "weatherCloud"
        var code = numberFrom(item, "ww", "weatherCode")
        if (code !== null) {
            code = Math.round(code)
            if (code === 96 || code === 99) return "weatherHail"
            if (code === 95 || code === 97 || code === 98) return "weatherStorm"
            if (code === 56 || code === 57 || code === 66 || code === 67) return "weatherFreezingRain"
            if (code === 68 || code === 69 || code === 83 || code === 84) return "weatherSleet"
            if (code === 71 || code === 73 || code === 75 || code === 85 || code === 86) return "weatherSnow"
            if (code === 51 || code === 53 || code === 55 || code === 61 || code === 63 || code === 65 || code === 80 || code === 81 || code === 82) return "weatherRain"
            if (code === 45 || code === 49) return "weatherFog"
            if (code === 0) return "weatherClear"
            if (code === 1 || code === 2) return "weatherPartly"
            if (code === 3) return "weatherCloud"
        }
        return "weatherUnknown"
    }

    function weatherDescription(item) {
        var explicit = textFrom(item, "condition", "summary")
        if (explicit.length) return explicit
        var code = numberFrom(item, "ww", "weatherCode")
        if (code !== null) {
            code = Math.round(code)
            var descriptions = ({
                0:"Klar", 1:"Auflockernd", 2:"Bewölkt", 3:"Zunehmend bewölkt",
                45:"Nebel", 49:"Eisnebel",
                51:"Leichter Sprühregen", 53:"Sprühregen", 55:"Starker Sprühregen",
                56:"Leicht gefrierender Sprühregen", 57:"Gefrierender Sprühregen",
                61:"Leichter Regen", 63:"Regen", 65:"Starker Regen",
                66:"Leicht gefrierender Regen", 67:"Gefrierender Regen",
                68:"Leichter Schneeregen", 69:"Schneeregen",
                71:"Leichter Schneefall", 73:"Schneefall", 75:"Starker Schneefall",
                80:"Leichter Regenschauer", 81:"Regenschauer", 82:"Heftiger Regenschauer",
                83:"Leichter Schneeregenschauer", 84:"Schneeregenschauer",
                85:"Leichter Schneeschauer", 86:"Schneeschauer",
                95:"Gewitter mit Regen oder Schnee",
                96:"Hagelgewitter", 97:"Starkes Gewitter", 98:"Gewitter", 99:"Starkes Hagelgewitter"
            })
            if (descriptions[code]) return descriptions[code]
        }
        return "Wetterlage"
    }

    function canActivate(item) {
        var command = item && item.command
        return item && item.available === true && command && command.target && command.action
    }

    function activate(item) {
        if (!canActivate(item) || !api) return
        var command = item.command
        var extra = ({})
        for (var key in command)
            if (key !== "target" && key !== "action" && key !== "value") extra[key] = command[key]
        api.command(command.target, command.action, command.value, extra)
    }

    function favoriteIcon(item) {
        var kinds = {
            "bulb":"cabinLight", "right-light":"sideRight", "down-light":"rearLight", "left-light":"sideLeft",
            "lightbar":"lightBar", "warningbar":"warningBar", "highbeam":"highBeam", "outlet":"outlet",
            "pump":"pump", "satellite":"satellite", "fan":"fan", "plug":"plug", "heater":"flame",
            "battery":"battery", "home":"home"
        }
        return kinds[item && item.icon] || "energy"
    }

    function favoriteIdAt(index) {
        return favoriteIds && index >= 0 && index < favoriteIds.length ? String(favoriteIds[index] || "") : ""
    }

    function favoriteForSlot(index) {
        var id = favoriteIdAt(index)
        for (var i = 0; favorites && i < favorites.length; ++i)
            if (String(favorites[i].id || "") === id) return favorites[i]
        return null
    }

    function favoriteSelectionName(index) {
        var id = favoriteIdAt(index)
        for (var i = 0; favoriteOptions && i < favoriteOptions.length; ++i) {
            if (String(favoriteOptions[i].id || "") !== id) continue
            var group = String(favoriteOptions[i].group || "")
            var name = String(favoriteOptions[i].name || id)
            return group ? group + " · " + name : name
        }
        return id || "Nicht belegt"
    }

    Rectangle {
        id: scrim
        anchors.fill: parent
        visible: panels.activePanel !== 0
        color: panels.dayMode ? "#6a87939c" : "#a8000509"
        opacity: panels.activePanel === 0 ? 0 : 1
        z: 20
        Behavior on opacity { NumberAnimation { duration: 140 } }
        MouseArea { anchors.fill: parent; onClicked: panels.close() }
    }

    Rectangle {
        id: favoritePanel
        objectName: "v2FavoritesPanel"
        x: panels.activePanel === -1 ? 0 : -width
        y: 0
        width: 340
        height: parent.height
        z: 30
        color: visual.panel
        border.color: visual.border
        border.width: 1
        clip: true
        Behavior on x { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent }

        V2Icon { x: 20; y: 17; width: 32; height: 32; kind: "favorite"; lineColor: visual.blue; strokeWidth: 1.8 }
        Text { x: 62; y: 18; width: 190; clip: true; elide: Text.ElideRight; text: "Favoriten"; color: visual.text; font.pixelSize: 20; font.bold: true }
        Text { objectName: "v2FavoritesSubtitle"; x: 62; y: 45; width: 190; clip: true; elide: Text.ElideRight; text: "Antippen zum Schalten"; color: visual.muted; font.pixelSize: 9; font.bold: true }
        Rectangle { x: 20; y: 69; width: 300; height: 1; color: visual.border }

        Repeater {
            model: 4
            delegate: Rectangle {
                property string favoriteId: panels.favoriteIdAt(index)
                property var favorite: panels.favoriteForSlot(index)
                property bool actionable: panels.canActivate(favorite)
                property bool favoriteActive: favorite && favorite.active === true
                property bool favoriteUnavailable: favorite && favorite.available === false
                x: 14; y: 80 + index * 78; width: 312; height: 68; radius: 14
                opacity: favoriteUnavailable ? .55 : 1
                color: favoriteActive ? visual.selectedBlue : visual.inner
                border.width: favoriteActive ? 2 : 1
                border.color: favoriteActive ? visual.blue : visual.border

                Rectangle {
                    x: 10; y: 12; width: 44; height: 44; radius: 12
                    color: favoriteActive ? visual.blue : visual.disabled
                    V2Icon {
                        anchors.centerIn: parent; width: 26; height: 26
                        kind: panels.favoriteIcon(favorite)
                        lineColor: favoriteActive ? "#ffffff" : visual.muted
                        strokeWidth: 1.8
                    }
                }
                Text {
                    objectName: "v2FavoriteName" + index
                    x: 64; y: 10; width: 132; clip: true; elide: Text.ElideRight
                    text: favorite && favorite.name ? favorite.name : panels.favoriteSelectionName(index)
                    color: visual.text; font.pixelSize: 12; font.bold: true
                }
                Text {
                    x: 64; y: 37; width: 132; clip: true; elide: Text.ElideRight
                    text: favorite && favorite.status ? favorite.status : (favoriteId ? "Wird aufgelöst" : "Nicht belegt")
                    color: favoriteActive ? visual.blue : visual.muted; font.pixelSize: 8
                }
                MouseArea {
                    x: 0; y: 0; width: 204; height: parent.height
                    enabled: parent.actionable
                    onClicked: panels.activate(parent.favorite)
                }
                Rectangle {
                    objectName: "v2FavoritePrevious" + index
                    x: 208; y: 12; width: 42; height: 44; radius: 11
                    color: favoritePreviousArea.pressed ? visual.pressed : visual.disabled
                    border.color: visual.border
                    Text { anchors.centerIn: parent; text: "−"; color: visual.text; font.pixelSize: 18 }
                    MouseArea {
                        id: favoritePreviousArea; anchors.fill: parent
                        enabled: panels.favoriteOptions && panels.favoriteOptions.length > 0
                        onClicked: if (panels.host) panels.host.changeFavorite(index, -1)
                    }
                }
                Rectangle {
                    objectName: "v2FavoriteNext" + index
                    x: 258; y: 12; width: 42; height: 44; radius: 11
                    color: favoriteNextArea.pressed ? visual.pressed : visual.disabled
                    border.color: visual.border
                    Text { anchors.centerIn: parent; text: "+"; color: visual.text; font.pixelSize: 18 }
                    MouseArea {
                        id: favoriteNextArea; anchors.fill: parent
                        enabled: panels.favoriteOptions && panels.favoriteOptions.length > 0
                        onClicked: if (panels.host) panels.host.changeFavorite(index, 1)
                    }
                }
            }
        }

        Text {
            objectName: "v2FavoritesEditorLabel"
            x: 14; y: 407; width: 132; height: 32; clip: true; elide: Text.ElideRight
            text: "Favoriten auswählen"
            color: visual.muted; font.pixelSize: 9; font.bold: true; verticalAlignment: Text.AlignVCenter
        }
        Rectangle {
            id: favoriteSaveButton
            objectName: "v2FavoriteSaveButton"
            x: 158; y: 401; width: 168; height: 44; radius: 11
            color: favoriteSaveArea.pressed ? visual.pressed : visual.selectedBlue
            border.color: visual.blue
            opacity: panels.favoriteIds && panels.favoriteIds.length > 0 ? 1 : .45
            Text { anchors.centerIn: parent; text: "AUSWAHL SPEICHERN"; color: visual.blue; font.pixelSize: 8; font.bold: true }
            MouseArea {
                id: favoriteSaveArea; anchors.fill: parent
                enabled: panels.favoriteIds && panels.favoriteIds.length > 0
                onClicked: if (panels.host) panels.host.saveFavorite()
            }
        }
        Text {
            x: 14; y: 451; width: 312; clip: true; elide: Text.ElideRight
            text: "Nicht verfügbare Favoriten bleiben schreibgeschützt."
            color: visual.muted; font.pixelSize: 7
        }
    }

    Rectangle {
        id: weatherPanel
        objectName: "v2WeatherPanel"
        x: panels.activePanel === 1 ? panels.width - width : panels.width
        y: 0
        width: 560
        height: parent.height
        z: 30
        color: visual.backgroundTop
        border.color: visual.border
        border.width: 1
        clip: true
        gradient: Gradient {
            GradientStop { position: 0; color: visual.backgroundTop }
            GradientStop { position: 1; color: visual.backgroundBottom }
        }
        Behavior on x { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

        MouseArea { anchors.fill: parent }

        // Weather layout is a direct Qt 5 port of the GX/WASM 560x480 panel.
        V2Icon {
            x: 17; y: 14; width: 27; height: 27
            kind: "climate"; lineColor: visual.blue; strokeWidth: 1.8
        }
        Text {
            x: 55; y: 0; width: 438; height: 54
            verticalAlignment: Text.AlignVCenter
            text: "Wetter"; color: visual.text; font.pixelSize: 18; font.weight: Font.DemiBold
        }
        Rectangle { x: 0; y: 54; width: parent.width; height: 1; color: visual.border }

        Rectangle {
            objectName: "v2WeatherCurrentCard"
            visible: panels.weatherAvailable
            x: 16; y: 64; width: 170; height: 174; radius: 17
            color: visual.panel; border.color: visual.border
            Rectangle {
                x: 12; y: 11; width: 44; height: 20; radius: 10
                color: visual.selectedBlue
                Text { anchors.centerIn: parent; text: "DWD"; color: visual.blue; font.pixelSize: 9; font.bold: true }
            }
            V2Icon {
                x: 93; y: 8; width: 62; height: 62
                kind: panels.weatherIcon(panels.currentWeather)
                lineColor: visual.text; sunColor: visual.yellow; rainColor: visual.blue; strokeWidth: 2
            }
            Text { x: 13; y: 42; width: 83; text: panels.temperatureText(panels.currentWeather); color: visual.text; font.pixelSize: 31; font.weight: Font.DemiBold }
            Text { x: 13; y: 88; width: 144; elide: Text.ElideRight; text: panels.weatherDescription(panels.currentWeather); color: visual.text; font.pixelSize: 11; font.weight: Font.DemiBold }
            Text {
                x: 13; y: 113; width: 144
                text: {
                    var probability = panels.rainProbability(panels.currentWeather)
                    return "Regen " + (probability === null ? "–" : probability.toFixed(0) + " %")
                }
                color: visual.blue; font.pixelSize: 9
            }
            Text {
                x: 13; y: 134; width: 144
                text: {
                    var wind = panels.numberFrom(panels.currentWeather, "windKmh", "windSpeedKmh")
                    if (wind === null) wind = panels.numberFrom(panels.currentWeather, "windSpeed", "wind")
                    return "Wind " + (wind === null ? "–" : wind.toFixed(0) + " km/h")
                }
                color: visual.muted; font.pixelSize: 9
            }
        }

        Rectangle {
            objectName: "v2WeatherChartCard"
            visible: panels.weatherAvailable
            x: 196; y: 64; width: 348; height: 174; radius: 17
            color: visual.panel; border.color: visual.border
            Text { x: 13; y: 10; text: "Nächste 24 Stunden"; color: visual.text; font.pixelSize: 11; font.weight: Font.DemiBold }
            Row {
                x: parent.width - width - 13; y: 12; spacing: 8
                Rectangle { width: 19; height: 3; radius: 2; color: visual.orange; anchors.verticalCenter: parent.verticalCenter }
                Text { text: "Temperatur"; color: visual.muted; font.pixelSize: 8 }
                Rectangle { width: 13; height: 8; radius: 2; color: visual.blue; opacity: .55; anchors.verticalCenter: parent.verticalCenter }
                Text { text: "Regen"; color: visual.muted; font.pixelSize: 8 }
                Rectangle { visible: panels.tideCurveAvailable; width: visible ? 19 : 0; height: 2; radius: 1; color: panels.tideColor; anchors.verticalCenter: parent.verticalCenter }
                Text { visible: panels.tideCurveAvailable; text: "Tide"; color: visual.muted; font.pixelSize: 8 }
            }
            Canvas {
                id: gxWeatherChart
                objectName: "v2Weather24HourChart"
                x: 8; y: 32; width: 332; height: 135
                property var hourlyData: panels.hourlyForecast
                property var tideData: panels.tideCurve
                property bool dayPalette: panels.dayMode
                property color tideColor: panels.tideColor
                onHourlyDataChanged: requestPaint()
                onTideDataChanged: requestPaint()
                onDayPaletteChanged: requestPaint()
                onTideColorChanged: requestPaint()
                onPaint: {
                    var context = getContext("2d")
                    context.clearRect(0, 0, width, height)
                    var count = Math.min(24, hourlyData && hourlyData.length ? hourlyData.length : 0)
                    var left = 43
                    var rightPadding = panels.tideCurveAvailable ? 43 : 13
                    var right = width - rightPadding
                    var top = 12
                    var bottomPadding = 25
                    var chartHeight = height - top - bottomPadding
                    var chartWidth = right - left
                    context.lineWidth = 1
                    context.strokeStyle = visual.border
                    context.fillStyle = visual.muted
                    context.font = "8px sans-serif"
                    for (var grid = 0; grid <= 3; ++grid) {
                        var gridY = top + chartHeight * grid / 3
                        context.beginPath(); context.moveTo(left, gridY); context.lineTo(right, gridY); context.stroke()
                    }
                    if (!count) {
                        context.font = "11px sans-serif"
                        context.fillText("Noch keine 24-h-Prognose", left + 12, top + chartHeight / 2)
                        return
                    }
                    var firstWeatherTime = new Date(hourlyData[0].t).getTime()
                    if (isNaN(firstWeatherTime)) return
                    var firstTideTime = panels.tideCurveAvailable ? new Date(tideData[0].t).getTime() : NaN
                    var chartStart = !isNaN(firstTideTime) ? firstTideTime : firstWeatherTime
                    var chartEnd = chartStart + 24 * 60 * 60 * 1000
                    var chartDuration = chartEnd - chartStart
                    function itemTime(item, index) {
                        var parsed = new Date(item && item.t).getTime()
                        return isNaN(parsed) ? chartStart + index * 60 * 60 * 1000 : parsed
                    }
                    function chartX(time) {
                        return left + Math.max(0, Math.min(1, (time - chartStart) / chartDuration)) * chartWidth
                    }
                    var minimum = 1000
                    var maximum = -1000
                    for (var rangeIndex = 0; rangeIndex < count; ++rangeIndex) {
                        var rangeTemperature = panels.numberFrom(hourlyData[rangeIndex], "tempC", "temperature")
                        if (rangeTemperature === null) rangeTemperature = panels.numberFrom(hourlyData[rangeIndex], "temperatureC", "temp")
                        if (rangeTemperature !== null) {
                            minimum = Math.min(minimum, rangeTemperature)
                            maximum = Math.max(maximum, rangeTemperature)
                        }
                    }
                    if (minimum === 1000 || maximum === -1000) { minimum = 0; maximum = 1 }
                    if (maximum - minimum < 3) { maximum += 1.5; minimum -= 1.5 }
                    var hourWidth = chartWidth / 24
                    context.save()
                    context.globalAlpha = panels.dayMode ? .5 : .38
                    context.fillStyle = visual.blue
                    for (var bar = 0; bar < count; ++bar) {
                        var probability = panels.rainProbability(hourlyData[bar])
                        if (probability === null) probability = 0
                        probability = Math.max(0, Math.min(100, probability))
                        var barHeight = chartHeight * .38 * probability / 100
                        var barX = chartX(itemTime(hourlyData[bar], bar))
                        context.fillRect(barX - Math.max(1, hourWidth * .25), top + chartHeight - barHeight, Math.max(2, hourWidth * .5), barHeight)
                    }
                    context.restore()
                    context.strokeStyle = visual.orange
                    context.lineWidth = 2.4
                    context.beginPath()
                    var started = false
                    for (var point = 0; point < count; ++point) {
                        var pointTemperature = panels.numberFrom(hourlyData[point], "tempC", "temperature")
                        if (pointTemperature === null) pointTemperature = panels.numberFrom(hourlyData[point], "temperatureC", "temp")
                        if (pointTemperature === null) continue
                        var pointX = chartX(itemTime(hourlyData[point], point))
                        var pointY = top + (maximum - pointTemperature) / (maximum - minimum) * chartHeight * .72
                        if (!started) { context.moveTo(pointX, pointY); started = true } else context.lineTo(pointX, pointY)
                    }
                    if (started) context.stroke()
                    if (panels.tideCurveAvailable) {
                        var visibleTides = []
                        var tideMinimum = 1000
                        var tideMaximum = -1000
                        for (var tideIndex = 0; tideIndex < tideData.length; ++tideIndex) {
                            var tideTime = new Date(tideData[tideIndex].t).getTime()
                            if (tideTime < chartStart || tideTime > chartEnd) continue
                            visibleTides.push(tideData[tideIndex])
                            tideMinimum = Math.min(tideMinimum, tideData[tideIndex].heightM)
                            tideMaximum = Math.max(tideMaximum, tideData[tideIndex].heightM)
                        }
                        if (visibleTides.length >= 2) {
                            if (tideMaximum - tideMinimum < .1) { tideMaximum += .05; tideMinimum -= .05 }
                            var tideSpan = tideMaximum - tideMinimum
                            // SYNC 3's older Qt Canvas needs a typed QML color here.
                            // A raw JavaScript string can leave the previous orange stroke active.
                            context.strokeStyle = tideColor
                            context.lineWidth = 1.8
                            context.beginPath()
                            for (var visibleIndex = 0; visibleIndex < visibleTides.length; ++visibleIndex) {
                                var visibleTime = new Date(visibleTides[visibleIndex].t).getTime()
                                var tideX = chartX(visibleTime)
                                var tideY = top + (tideMaximum - visibleTides[visibleIndex].heightM) / tideSpan * chartHeight * .72
                                if (visibleIndex === 0) context.moveTo(tideX, tideY); else context.lineTo(tideX, tideY)
                            }
                            context.stroke()
                            context.fillStyle = tideColor
                            context.font = "7px sans-serif"
                            context.textAlign = "left"
                            context.fillText(tideMaximum.toFixed(1).replace(".", ",") + " m", right + 3, top + 7)
                            context.fillText(tideMinimum.toFixed(1).replace(".", ",") + " m", right + 3, top + chartHeight * .72 + 2)
                        }
                    }
                    context.fillStyle = visual.muted
                    context.font = "8px sans-serif"
                    for (var hours = 0; hours <= 24; hours += 6) {
                        var labelTime = new Date(chartStart + hours * 60 * 60 * 1000)
                        var labelX = left + hours / 24 * chartWidth
                        context.textAlign = "left"
                        context.fillText(Qt.formatTime(labelTime, "hh:mm"), Math.max(1, Math.min(width - 27, labelX - 12)), height - 7)
                    }
                    context.fillStyle = visual.orange
                    context.font = "8px sans-serif"
                    context.textAlign = "left"
                    context.fillText(Math.ceil(maximum) + " °C", 3, top + 7)
                    context.fillText(Math.floor(minimum) + " °C", 3, top + chartHeight * .72 + 2)
                }
            }
        }

        Rectangle {
            objectName: "v2WeatherForecastCard"
            visible: panels.weatherAvailable
            x: 16; y: 248; width: 528; height: 174; radius: 17
            color: visual.panel; border.color: visual.border
            Text { x: 13; y: 10; text: "6-Tage-Vorschau"; color: visual.text; font.pixelSize: 11; font.weight: Font.DemiBold }
            Repeater {
                model: Math.min(6, panels.dailyForecast.length)
                delegate: Rectangle {
                    property var dayItem: panels.dailyForecast[index]
                    x: 9 + index * ((parent.width - 53) / 6 + 7); y: 34
                    width: (parent.width - 53) / 6; height: 126; radius: 12
                    color: visual.inner; border.color: visual.border
                    Text { x: 0; y: 8; width: parent.width; horizontalAlignment: Text.AlignHCenter; text: panels.dailyLabel(parent.dayItem).replace(".", ""); color: visual.text; font.pixelSize: 10; font.weight: Font.DemiBold }
                    V2Icon { x: (parent.width - 42) / 2; y: 29; width: 42; height: 42; kind: panels.weatherIcon(parent.dayItem); lineColor: visual.text; sunColor: visual.yellow; rainColor: visual.blue; strokeWidth: 1.6 }
                    Text {
                        x: 0; y: 75; width: parent.width; horizontalAlignment: Text.AlignHCenter
                        text: {
                            var minimum = panels.minimumTemperature(parent.dayItem)
                            var maximum = panels.maximumTemperature(parent.dayItem)
                            return (minimum === null ? "–" : minimum.toFixed(0)) + "°  " + (maximum === null ? "–" : maximum.toFixed(0)) + "°"
                        }
                        color: visual.text; font.pixelSize: 10; font.weight: Font.DemiBold
                    }
                    Text {
                        x: 0; y: 99; width: parent.width; horizontalAlignment: Text.AlignHCenter
                        text: {
                            var chance = panels.rainProbability(parent.dayItem)
                            return chance === null ? "–" : chance.toFixed(0) + " %"
                        }
                        color: visual.blue; font.pixelSize: 9
                    }
                }
            }
            Text { visible: panels.dailyForecast.length === 0; anchors.centerIn: parent; text: "Noch keine Tagesprognose"; color: visual.muted; font.pixelSize: 11 }
        }

        Text {
            objectName: "v2WeatherSunTide"
            visible: panels.weatherAvailable && (panels.sunLabel().length > 0 || panels.tideLabel().length > 0)
            x: 18; y: 429; width: 524; height: 17; clip: true; elide: Text.ElideRight
            text: [panels.sunLabel(), panels.tideLabel()].filter(function(value) { return value.length > 0 }).join("   ·   ")
            color: panels.tides && panels.tides.stale === true ? visual.orange : visual.muted
            font.pixelSize: 9
        }
        Text {
            objectName: "v2WeatherSourceLine"
            visible: panels.weatherAvailable
            x: 18; y: 449; width: 524; clip: true; elide: Text.ElideRight
            text: "Quelle: Deutscher Wetterdienst · " + panels.weatherLocation()
                    + (panels.weatherUpdatedText().length ? " · " + panels.weatherUpdatedText() : "")
                    + (panels.weather && panels.weather.stale === true ? " · Daten veraltet" : "")
            color: panels.weather && panels.weather.stale === true ? visual.orange : visual.muted
            font.pixelSize: 9
        }
        Text {
            visible: !panels.weatherAvailable
            x: 16; y: 64; width: 528; height: 404
            verticalAlignment: Text.AlignVCenter; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap
            text: panels.weather && panels.weather.status ? String(panels.weather.status) : "Wetterdaten noch nicht verfügbar"
            color: visual.muted; font.pixelSize: 11
        }

    }

    Rectangle {
        id: closeButton
        objectName: "v2EdgePanelClose"
        visible: panels.activePanel !== 0
        x: panels.activePanel === -1 ? 288 : panels.width - 52
        y: 5
        width: 44
        height: 44
        radius: 13
        z: 50
        color: closeArea.pressed ? visual.pressed : visual.inner
        border.color: visual.border
        V2Icon { anchors.centerIn: parent; width: 22; height: 22; kind: "close"; lineColor: visual.text; strokeWidth: 2 }
        MouseArea { id: closeArea; anchors.fill: parent; onClicked: panels.close() }
    }

    Rectangle {
        id: favoritesHeaderButton
        objectName: "v2FavoritesHeaderButton"
        visible: panels.activePanel === 0
        property bool active: panels.activePanel === -1
        x: 512; y: 6; width: 42; height: 42; radius: 12
        z: 60
        color: favoritesHeaderArea.pressed ? visual.pressed : (active ? visual.selectedBlue : visual.inner)
        border.color: active ? visual.blue : visual.border
        border.width: active ? 2 : 1
        V2Icon {
            anchors.centerIn: parent; width: 22; height: 22; kind: "favorite"
            lineColor: favoritesHeaderButton.active ? visual.blue : visual.muted; strokeWidth: 1.8
        }
        MouseArea { id: favoritesHeaderArea; anchors.fill: parent; onClicked: panels.openFavorites() }
    }

    Rectangle {
        id: weatherHeaderButton
        objectName: "v2WeatherHeaderButton"
        visible: panels.activePanel === 0
        property bool active: panels.activePanel === 1
        x: 560; y: 6; width: 42; height: 42; radius: 12
        z: 60
        color: weatherHeaderArea.pressed ? visual.pressed : (active ? visual.selectedBlue : visual.inner)
        border.color: active ? visual.blue : visual.border
        border.width: active ? 2 : 1
        V2Icon {
            anchors.centerIn: parent; width: 23; height: 23; kind: "weatherCloud"
            lineColor: weatherHeaderButton.active ? visual.blue : visual.muted; strokeWidth: 1.8
        }
        MouseArea { id: weatherHeaderArea; anchors.fill: parent; onClicked: panels.openWeather() }
    }

    MouseArea {
        id: leftEdge
        objectName: "v2LeftEdgeSwipe"
        visible: panels.activePanel === 0
        x: 0; y: 56; width: 18; height: 335
        z: 10
        property real startX: 0
        property real startY: 0
        propagateComposedEvents: true
        onPressed: { startX = mouse.x; startY = mouse.y }
        onReleased: {
            var dx = mouse.x - startX
            var dy = mouse.y - startY
            if (dx >= 48 && Math.abs(dx) > Math.abs(dy) * 1.5) panels.openFavorites()
            else mouse.accepted = false
        }
        onClicked: mouse.accepted = false
    }

    MouseArea {
        id: rightEdge
        objectName: "v2RightEdgeSwipe"
        visible: panels.activePanel === 0
        x: 782; y: 56; width: 18; height: 335
        z: 10
        property real startX: 0
        property real startY: 0
        propagateComposedEvents: true
        onPressed: { startX = mouse.x; startY = mouse.y }
        onReleased: {
            var dx = startX - mouse.x
            var dy = mouse.y - startY
            if (dx >= 48 && Math.abs(dx) > Math.abs(dy) * 1.5) panels.openWeather()
            else mouse.accepted = false
        }
        onClicked: mouse.accepted = false
    }
}
